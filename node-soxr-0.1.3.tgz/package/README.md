# Node-SoxR

Node.js native addon wrapper for libsoxr (high quality and high performance offline audio resampler).

---

## Installation

#### Requirements:

- Node.js >= 24 (Binaries are built on LTS node. Please rebuild from source manually if you want a different node target.)

#### Setup (with npm):

    npm i node-soxr

## Usage:

```typescript
import { SoxrWrapper, SoxrQuality } from "node-soxr";

const soxr = new SoxrWrapper(48000, 44100, 2);
const resampledData = soxr.resample(data);
```

###### VBR Resampling is currently not supported.

---
